#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<string.h>

#define FAILURE -1
#define SUCCESS 0
#define DATA_NOT_FOUND -2

typedef struct node
{
    char filename[45];
    struct node *link;
} f_name;

typedef struct sub_n
{
    int wordcount;
    char filename[50];
    struct sub_n *slink;

}S_node;
typedef struct main_n
{
    char word[50];
    int filecount;
    struct sub_n *slink;
    struct main_n *mlink;
}M_node;

int getIntegerInput();

// validation prototype
int validation_file(int argc, char *argv[], f_name **files);

int insert_to_list( char *argv, f_name **);

// Display function prototype
int Display_database(M_node **hash_table);

// create function prototype
int create_database( f_name **files, M_node **hash_table );




// search word prototype
int search_word( M_node **hash_table, char *word);

// save database prototype
int save_database( M_node **hash_table , char *file );

//update database prototype
int update_database( M_node **hash_table );

//update database validation prototype
int backup_validate( char *file );

