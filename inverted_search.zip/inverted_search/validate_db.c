#include "Main.h"

int validation_file(int argc, char *argv[], f_name **files)
{
    for(int i = 1; i < argc; i++)
    {
	if(strstr(argv[i],".txt") != NULL) 
	{
	    FILE *temp;
	    if((temp = fopen(argv[i], "r")) != NULL)
	    {
		fseek(temp, 0, SEEK_END);
		if(ftell(temp) != 0)
		{
		    if(insert_to_list(argv[i], files) == FAILURE)
		    {
			return FAILURE;
		    }
		}
		else
		    printf("%s file is empty.\n", argv[i]);
		fclose(temp);
	    }
	    else
		printf("%s file not exist.\n", argv[i]);
	}else
	{
		if(argc ==2)
		{
		printf("Input file should be .txt extension\n");
		return FAILURE;
		}
	}
    }
    return SUCCESS;
}
int insert_to_list( char *argv, f_name **files)
{
    f_name *new = malloc(sizeof(f_name));
    if(new == NULL)
	return FAILURE;
    strcpy(new -> filename, argv);
    new -> link = NULL;
    if(*files == NULL)
    {
	*files = new;
	    printf("%s file is added\n", argv);
    }
    else
    {
	f_name *t = *files;
	while(t -> link)
	{
	    if(!strcmp(t -> filename, argv))
		break;
	    t = t -> link;
	}
	if(strcmp(t -> filename, argv))
	{
	    t -> link = new;
	    printf("%s file is added\n", argv);
	}
	else
	{
	    printf("%s file is already exist.\n", argv);
	    free(new);
	}
    }
    return SUCCESS;
}


