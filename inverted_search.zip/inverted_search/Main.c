#include "Main.h"

int main(int argc, char *argv[])
{
    
	if(argc <2 )
	{
		printf("Isufficient arguments\n");
		return 0;
	}
    int option = 0, flag = 0, res = 0;
    char word[20];
    f_name *files = NULL;
    if(validation_file( argc, argv, &files ) == FAILURE)
    {
	printf("Validation of files failure\n");
	return 0;
    }
    else
	printf("Validation of files successfull\n");

    M_node *hash_table[27] = {NULL};
	for (int i = 0; i < 27; i++) {
    if (hash_table[i] != NULL) 
        printf("Hash table [%d] is not empty\n", i);
}


    printf("1.Create\n2.Display\n3.Search\n4.Save\n5.Update\n6.Exit\n");
    while(1)
    {
	printf("Enter the choice :");
	option = getIntegerInput();
	switch(option)
	{
	    case 1:if( flag == 0) 
		   {
		       if((res = create_database( &files, hash_table )) == SUCCESS)
		       {
			   flag = 1;
			   printf("Creating database successfull\n");
		       }
		       else if(res == DATA_NOT_FOUND )
		       {
			   printf("Pass the file names through CML\n");
		       }
		       else
		       {
			   printf("Creating database failure\n");
		       }
		   }
		   else
		       printf("Data is already present in database\n");
		   break;

	    case 2: if(Display_database(hash_table) == SUCCESS)
		    {
			printf("Displaying data successfull\n");
		    }
		    else
			printf("Data not found\n");
		    break;
       case 3: 
       printf("Enter the word to search: ");
       scanf("%s", word);

       // Convert the search word to lowercase
      for (int i = 0; word[i]; i++) {
        word[i] = tolower(word[i]);
        }

    if(search_word(hash_table, word) == DATA_NOT_FOUND)
    {
        printf("Given word is not present \n");
    }
    break;

	    case 4: if(flag == 1)
		    {
			printf("Enter the file name : ");
			scanf("%s", word);

			if(strstr(word, ".txt") != NULL)
			{
			    if(save_database( hash_table , word ) == FAILURE)
			    {
				printf("Saving database failure\n");
			    }
			    else
			    {
				printf("Data base saved succesfully\n");
			    }
			}
			else
			    printf("Enter .txt file\n"); 
		    }
		    else
			printf("No Data present in database to save\n");
		    break;

	    case 5: if(flag == 0)
		    {
			if((res = update_database( hash_table )) == SUCCESS )
			{
			    printf("Restored succesfully\n");
			    flag = 1;
			}
			else if( res == DATA_NOT_FOUND )
			{
			    printf("Enter the backup file containg backup data\n");
			}
			else
			{
			    printf("Restoring database failure\n");
				printf("Due to the some other extension other than .txt\n");
				
			}
		    }
		    else
			printf("Data already exist\n");
		    break;

	    case 6: return SUCCESS;

	    default: printf("Enter the correct option\n");
	}
    }
}


int getIntegerInput() {
    int input;
    char buffer[100];

    while (1) {
        printf("\nEnter your choice: ");
        if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
            // Check if input is a number
            if (sscanf(buffer, "%d", &input) == 1 && input >= 1 && input <= 6) {
                return input; // Valid number input
            } else {
                printf("\n\n\t\t\tINFO : Please enter only integer values between 1 and 6.\n");
            }
        }
    }
}


