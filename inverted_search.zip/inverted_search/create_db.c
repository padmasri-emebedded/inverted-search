#include "Main.h"

int create_database(f_name **files, M_node **hash_table)
{
    f_name *ftemp = *files;
    if(ftemp == NULL)
	return DATA_NOT_FOUND;

    while(ftemp != NULL) //loop for accessing files from the slist
    {
	FILE *fptr = fopen(ftemp -> filename , "r"); //file open
	char word[20];
	while(fscanf(fptr, "%s", word) != EOF)	//scaning word from array one by one
	{
		printf("Read word: %s\n", word);
		for (int i = 0; word[i]; i++) word[i] = tolower(word[i]);
	    int index = 0;
	    if(isalpha(word[0])) //condition to check wheather the given word starts with alphabet
		{
		index = tolower(word[0]) - 97;	//finding index
		printf("Word: %s, Index: %d\n", word, index);
		}
	    else
		index = 26;


	    if(hash_table[index] == NULL)
	    {
		//creating sub node
		S_node *snew = malloc(sizeof(S_node));
		if(snew == NULL)
		    return FAILURE;
		strcpy(snew -> filename, ftemp -> filename);
		snew -> wordcount = 1;
		snew -> slink = NULL;

		//creating main node
		M_node *mnew = malloc(sizeof(M_node));
		if(mnew == NULL)
		    return FAILURE;
		strcpy(mnew -> word, word);
		mnew -> filecount = 1;
		mnew -> mlink = NULL;

		mnew -> slink = snew; //update main node siblink with sub node

		hash_table[index] = mnew; //update hash_table with main node
	    }
	    else
	    {
		M_node *mprev = NULL;
		M_node *mtemp = hash_table[index]; 
		while( mtemp != NULL )
		{
		    if(!strcmp(mtemp -> word, word)) //if word is already present in hash table
		    {
			S_node *sprev = NULL;
			S_node *stemp = mtemp -> slink;
			while( stemp != NULL )
			{
			    if(!strcmp(stemp -> filename, ftemp -> filename))
			    {
				++stemp -> wordcount;
				break;
			    }
			    sprev = stemp;
			    stemp = stemp -> slink;
			}
			if(stemp == NULL)
			{
			    S_node *snew = malloc(sizeof(S_node));
			    if(snew == NULL)
				return FAILURE;
			    strcpy(snew -> filename, ftemp -> filename);
			    snew -> wordcount = 1;
			    snew -> slink = NULL;
			    sprev -> slink = snew;
			    ++mtemp -> filecount;
			}
			break;
		    }
		    mprev = mtemp;
		    mtemp = mtemp -> mlink;
		}
		if(mtemp == NULL) // if word is not present in hash table creating main node and linking to main link
		{
		    //creating sub node
		    S_node *snew = malloc(sizeof(S_node));
		    if(snew == NULL)
			return FAILURE;
		    strcpy(snew -> filename, ftemp -> filename);
		    snew -> wordcount = 1;
		    snew -> slink = NULL;

		    //creating main node
		    M_node *mnew = malloc(sizeof(M_node));
		    if(mnew == NULL)
			return FAILURE;
		    strcpy(mnew -> word, word);
		    mnew -> filecount = 1;
		    mnew -> mlink = NULL;

		    mnew -> slink = snew; //update main node siblink with sub node

		    mprev -> mlink = mnew; // updating main link
		}
	    }
	}
	ftemp = ftemp -> link;
    }
}
