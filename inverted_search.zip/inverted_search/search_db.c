#include"Main.h"

int search_word( M_node **hash_table, char *word)
{
	printf("Searching for word: %s\n", word);
    int i = 0;
    if(isalpha(word[0]))
	i = tolower(word[0]) - 97;
    else
	i = 26;
	printf("Search Index: %d\n", i);


    if(hash_table[i] == NULL)
    {
	return DATA_NOT_FOUND;
    }
    else
    {
	M_node *mtemp = hash_table[i];
	while( mtemp != NULL )
	{
	    if (!strcasecmp(word, mtemp->word))  // Case insensitive compare if( !strcmp(word, mtemp -> word))
	    {
		printf("The given word %s is present in %d files\n", mtemp -> word, mtemp -> filecount);

		S_node *stemp = mtemp -> slink;

		printf("filename\twordcount\n");

		while( stemp ) 
		{
		    printf("%s\t\t%d\n", stemp -> filename, stemp -> wordcount);
		    stemp = stemp -> slink;
		}
		return SUCCESS;
	    }
	    mtemp = mtemp -> mlink;
	}
	return DATA_NOT_FOUND;
    }
}

