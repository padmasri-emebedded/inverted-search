#include "Main.h"

int save_database(M_node **hash_table , char *file)
{
    FILE *fptr = fopen(file, "w");
    for(int i = 0; i < 27 ; i++)
    {
	if(hash_table[i] != NULL)
	{
	    M_node *mtemp = hash_table[i];
	    while( mtemp )
	    {
		fprintf(fptr, "#%d;%s;%d;", i, mtemp -> word, mtemp -> filecount);
		S_node *stemp = mtemp -> slink;
		while( stemp )
		{
		    fprintf(fptr, "%s;%d;" , stemp -> filename, stemp -> wordcount);
		    stemp = stemp -> slink;
		}
		fprintf(fptr, "%s" , "#\n"); 
		mtemp = mtemp -> mlink;
	    }
	}
    }
    return SUCCESS;
}


