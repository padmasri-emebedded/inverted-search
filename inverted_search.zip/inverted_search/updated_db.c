#include"Main.h"

int update_database( M_node **hash_table )
{
    char file[20];
    printf("Enter file name to backup: ");
    scanf("%s", file);

	
    int res = 0;
    if((res = backup_validate( file )) == FAILURE)
    {
	return FAILURE;
    }
    else if(res == DATA_NOT_FOUND)
    {
	return DATA_NOT_FOUND;
    }

    FILE *fptr = fopen( file ,"r" );
    char str[50];
    while(fscanf(fptr, "%s", str) != EOF)
    {
	int index = atoi( strtok(str,"#;"));

	M_node *mnew = malloc(sizeof(M_node));
	if( mnew == NULL )
	    return FAILURE;
	strcpy(mnew -> word, strtok(NULL, "#;"));
	mnew -> filecount = atoi(strtok(NULL, "#;"));
	mnew -> mlink = NULL;

	if( hash_table[index] == NULL )
	{
	    hash_table[index] = mnew;
	}
	else
	{
	    M_node *mtemp = hash_table[index];
	    while(mtemp -> mlink != NULL)
	    {
		mtemp = mtemp -> mlink;
	    } 

	    mtemp -> mlink = mnew;
	}

	for(int i = 1 ; i <= mnew -> filecount ; i++)
	{
	    S_node *snew = malloc(sizeof(S_node));
	    strcpy( snew -> filename, strtok(NULL, "#;"));
	    snew -> wordcount = atoi(strtok(NULL, "#;"));
	    snew -> slink = NULL;
	    if(i == 1)
	    {
		mnew -> slink = snew;
	    }
	    else
	    {
		S_node *stemp = mnew -> slink;
		while( stemp -> slink != NULL ) 
		{
		    stemp = stemp -> slink;
		}
		stemp -> slink = snew;
	    }
	}
    }
    return SUCCESS;
}
int backup_validate( char *file )
{
    if(strstr(file, ".txt") == NULL)
	return FAILURE;

    FILE *fptr = fopen( file ,"r" );
    if(fptr == NULL)
	return DATA_NOT_FOUND;

    fseek(fptr, 0, SEEK_END);

    if(ftell(fptr) != 0)
    {
	char ch;
	fseek(fptr, 0 , SEEK_SET);
	if((ch = fgetc(fptr)) == '#')
	{
	    fseek(fptr, -2 , SEEK_END);
	    ch = fgetc(fptr);
	    if(ch != '#')
	    {
		return DATA_NOT_FOUND;
	    }
	}
	else
	{
	    return DATA_NOT_FOUND;
	}
	fclose(fptr);
    }
    else
    {
	printf("ERROR: File is empty\n");
	return FAILURE;
    }
}
